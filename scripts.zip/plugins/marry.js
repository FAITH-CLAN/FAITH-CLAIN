module.exports = {
  command: 'marry',
  aliases: ['proposal'],
  category: 'fun',
  description: 'Propose marriage to someone (playful)',
  usage: '.marry @user',
  async handler(sock, message, args = [], context = {}) {
    const chatId = context.chatId || message.key.remoteJid;
    const by = message.key.participant || message.key.remoteJid;
    const target = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
      || message.message?.extendedTextMessage?.contextInfo?.participant;
    if (!target) return sock.sendMessage(chatId, { text: '❗ Mention someone to propose to.' }, { quoted: message });

    // playful random acceptance
    const accepted = Math.random() < 0.5;
    if (accepted) {
      await sock.sendMessage(chatId, { text: `💍 Congrats! @${target.split('@')[0]} accepted @${by.split('@')[0]}'s proposal!`, mentions: [target, by] }, { quoted: message });
    } else {
      await sock.sendMessage(chatId, { text: `😅 @${target.split('@')[0]} politely declined @${by.split('@')[0]}.`, mentions: [target, by] }, { quoted: message });
    }
  }
};
