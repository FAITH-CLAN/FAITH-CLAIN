module.exports = {
  command: 'slap',
  aliases: ['hit'],
  category: 'fun',
  description: 'Playfully slap someone by mentioning them',
  usage: '.slap @user',
  async handler(sock, message, args = [], context = {}) {
    const chatId = context.chatId || message.key.remoteJid;
    const by = message.key.participant || message.key.remoteJid;
    const target = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
      || message.message?.extendedTextMessage?.contextInfo?.participant;
    if (!target) {
      return sock.sendMessage(chatId, { text: '❗ Please mention someone to slap.' }, { quoted: message });
    }
    await sock.sendMessage(chatId, {
      text: `🤚 @${by.split('@')[0]} slaps @${target.split('@')[0]} playfully!`,
      mentions: [by, target]
    }, { quoted: message });
  }
};
