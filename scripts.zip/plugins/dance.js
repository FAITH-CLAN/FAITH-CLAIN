module.exports = {
  command: 'dance',
  aliases: ['boogie','danceparty'],
  category: 'fun',
  description: 'Make someone dance or start a dance party',
  usage: '.dance [@user]',
  async handler(sock, message, args = [], context = {}) {
    const chatId = context.chatId || message.key.remoteJid;
    const by = message.key.participant || message.key.remoteJid;
    const target = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    if (target) {
      await sock.sendMessage(chatId, { text: `🕺 @${target.split('@')[0]} is dancing thanks to @${by.split('@')[0]}!`, mentions: [target, by] }, { quoted: message });
    } else {
      await sock.sendMessage(chatId, { text: `🪩 Dance party started by @${by.split('@')[0]}! Everyone dance!`, mentions: [by] }, { quoted: message });
    }
  }
};
