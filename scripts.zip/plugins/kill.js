module.exports = {
  command: 'kill',
  aliases: ['frag'],
  category: 'fun',
  description: 'Pretend-kill someone (non-graphic, playful)',
  usage: '.kill @user',
  async handler(sock, message, args = [], context = {}) {
    const chatId = context.chatId || message.key.remoteJid;
    const by = message.key.participant || message.key.remoteJid;
    const target = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
      || message.message?.extendedTextMessage?.contextInfo?.participant;
    if (!target) return sock.sendMessage(chatId, { text: '❗ Mention someone to pretend-kill.' }, { quoted: message });
    await sock.sendMessage(chatId, {
      text: `💀 @${by.split('@')[0]} has vanquished @${target.split('@')[0]}! (playfight, no harm)`,
      mentions: [by, target]
    }, { quoted: message });
  }
};
