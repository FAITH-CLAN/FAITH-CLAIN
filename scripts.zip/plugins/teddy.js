let teddyUsers = {};

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

module.exports = {
    command: 'teddy',
    aliases: [],
    category: 'fun',
    description: 'Send an animated teddy with cute emojis',
    usage: '.teddy',
    async handler(sock, message, args, context = {}) {
        const chatId = context.chatId || message.key.remoteJid;
        const sender = message.key.participant || message.key.remoteJid;

        if (teddyUsers[sender]) return;
        teddyUsers[sender] = true;

        const teddyEmojis = [
            '❤','💕','😻','🧡','💛','💚','💙','💜','🖤','❣',
            '💞','💓','💗','💖','💘','💝','💟','♥','💌','🙂',
            '🤗','😌','😉','🤗','😊','🎊','🎉','🎁','🎈'
        ];

        let backgroundStarted = false;

        const animateTeddy = async (pingMsg) => {
            try {
                for (let i = 0; i < teddyEmojis.length; i++) {
                    await sleep(500);

                    await sock.relayMessage(
                        chatId,
                        {
                            protocolMessage: {
                                key: pingMsg.key,
                                type: 14,
                                editedMessage: {
                                    conversation: `(\_/)
( •.•)
/>${teddyEmojis[i]}`
                                }
                            }
                        },
                        {}
                    );
                }
            } catch (bgErr) {
                console.error('Error in teddy command background:', bgErr);
            } finally {
                delete teddyUsers[sender];
            }
        };

        try {
            const pingMsg = await sock.sendMessage(chatId, { text: `(\_/)
( •.•)
/>🤍` }, { quoted: message });
            backgroundStarted = true;
            animateTeddy(pingMsg);
            return;
        } catch (err) {
            console.error('Error in teddy command:', err);
            try {
                await sock.sendMessage(chatId, { text: '❌ Something went wrong while sending teddy emojis.' }, { quoted: message });
            } catch {}
        } finally {
            if (!backgroundStarted) delete teddyUsers[sender];
        }
    }
};
