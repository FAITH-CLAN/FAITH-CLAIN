module.exports = {
  command: 'punch',
  aliases: ['punchme'],
  category: 'fun',
  description: 'Punch someone (joking)',
  usage: '.punch @user',
  async handler(sock, message, args = [], context = {}) {
    const chatId = context.chatId || message.key.remoteJid;
    const by = message.key.participant || message.key.remoteJid;
    const target = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
      || message.message?.extendedTextMessage?.contextInfo?.participant;
    if (!target) return sock.sendMessage(chatId, { text: '❗ Mention someone to punch.' }, { quoted: message });
    await sock.sendMessage(chatId, {
      text: `🥊 @${by.split('@')[0]} punches @${target.split('@')[0]} — it was just a joke!`,
      mentions: [by, target]
    }, { quoted: message });
  }
};
